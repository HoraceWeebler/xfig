extern int read_1_3_objects (FILE *fp, char *buf, F_compound *obj);
