extern void anglemeas_selected (void);
extern void areameas_selected (void);
extern void lenmeas_selected (void);
