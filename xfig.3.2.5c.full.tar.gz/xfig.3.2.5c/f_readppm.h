extern int read_ppm (FILE *file, int filetype, F_pic *pic);
