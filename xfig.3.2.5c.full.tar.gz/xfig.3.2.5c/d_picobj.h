extern void picobj_drawing_selected (void);
