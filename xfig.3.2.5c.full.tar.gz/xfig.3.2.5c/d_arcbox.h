extern void arcbox_drawing_selected (void);
