extern void join_split_selected (void);
