extern int read_xbm (FILE *file, int filetype, F_pic *pic);
