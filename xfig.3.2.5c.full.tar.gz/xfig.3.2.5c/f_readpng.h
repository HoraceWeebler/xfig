extern int read_png (FILE *file, int filetype, F_pic *pic);
