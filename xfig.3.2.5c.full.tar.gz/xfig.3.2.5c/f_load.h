extern int load_file (char *file, int xoff, int yoff);
extern int update_recent_list (char *file);
extern void merge_file(char *file, int xoff, int yoff);
