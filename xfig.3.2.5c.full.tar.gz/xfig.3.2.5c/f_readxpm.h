extern int read_xpm ();
