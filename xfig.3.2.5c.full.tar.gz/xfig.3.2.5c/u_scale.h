extern int read_scale_arcs (F_arc *arcs, float mul, int offset);
extern int read_scale_compound (F_compound *compound, float mul, int offset);
extern int read_scale_compounds (F_compound *compounds, float mul, int offset);
extern int read_scale_ellipses (F_ellipse *ellipses, float mul, int offset);
extern int read_scale_lines (F_line *lines, float mul, int offset);
extern int read_scale_splines (F_spline *splines, float mul, int offset);
extern int read_scale_texts (F_text *texts, float mul, int offset);
