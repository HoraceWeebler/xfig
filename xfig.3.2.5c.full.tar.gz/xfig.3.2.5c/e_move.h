extern void move_selected (void);
