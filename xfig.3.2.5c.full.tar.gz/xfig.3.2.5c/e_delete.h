extern int delete_all (void);
extern void delete_selected (void);
