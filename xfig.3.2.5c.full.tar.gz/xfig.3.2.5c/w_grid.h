extern void init_grid (void);
extern void setup_grid (void);
