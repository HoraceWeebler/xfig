extern void align_selected (void);
