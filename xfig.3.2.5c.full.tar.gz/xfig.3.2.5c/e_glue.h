extern int compose_compound (F_compound *c);
extern int tag_obj_in_region (int xmin, int ymin, int xmax, int ymax);
extern void compound_selected (void);
