extern int read_gif (FILE *file, int filetype, F_pic *pic);
