extern int read_epsf (FILE *file, int filetype, F_pic *pic);
