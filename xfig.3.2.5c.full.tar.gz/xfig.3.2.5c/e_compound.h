extern void close_all_compounds (void);
extern void open_compound_selected (void);
