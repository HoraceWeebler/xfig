extern int read_jpg ();
