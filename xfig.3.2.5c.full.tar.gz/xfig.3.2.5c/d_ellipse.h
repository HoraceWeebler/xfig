extern void circle_ellipse_bydiameter_drawing_selected (void);
extern void circle_ellipse_byradius_drawing_selected (void);
