extern int assign_newboxpoint (F_line *b, int x1, int y1, int x2, int y2);
extern void move_point_selected (void);
