extern int read_pcx (FILE *file, int filetype, F_pic *pic);
extern int read_pcx (FILE *file, int filetype, F_pic *pic);
