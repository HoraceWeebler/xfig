extern void break_selected (void);
