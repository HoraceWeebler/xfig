extern void tangent_selected (void);
