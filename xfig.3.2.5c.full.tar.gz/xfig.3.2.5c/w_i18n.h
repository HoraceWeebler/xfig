extern Boolean is_i18n_font ();
extern Boolean is_i18n_font ();
extern void i18n_draw_image_string ();
extern void i18n_draw_string ();
extern void i18n_text_extents ();
