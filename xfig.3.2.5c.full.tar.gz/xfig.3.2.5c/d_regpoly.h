extern void regpoly_drawing_selected (void);
