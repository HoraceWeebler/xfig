extern int translate_arc (F_arc *arc, int dx, int dy);
extern int translate_compound (F_compound *compound, int dx, int dy);
extern int translate_ellipse (F_ellipse *ellipse, int dx, int dy);
extern int translate_line (F_line *line, int dx, int dy);
extern int translate_spline (F_spline *spline, int dx, int dy);
extern int translate_text (F_text *text, int dx, int dy);
