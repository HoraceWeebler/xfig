extern int read_tif (char *filename, int filetype, F_pic *pic);
